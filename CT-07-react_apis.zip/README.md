# ira
IRA is a system for tracking and repprting investor participation in Real Estate deals
